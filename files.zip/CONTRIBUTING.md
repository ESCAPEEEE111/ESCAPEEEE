# Contributing to Nowhere Digital

Thank you for your interest in contributing!

## How to Contribute

- Fork the repo and create your branch from `main`.
- Make your changes, add tests if possible.
- Ensure all tests pass (`npm test`, backend test suite).
- Open a pull request with a clear description.

## Issue Reporting

- For bugs, use the "Bug Report" template.
- For enhancements, use the "Feature Request" template.

## Code Style

- Frontend: Prettier, ESLint, Tailwind CSS.
- Backend: Black, isort, flake8 for Python.

## Communication

- Please be respectful and constructive.
- Propose large changes via issues for discussion before PRs.

Thanks for helping build Nowhere Digital!