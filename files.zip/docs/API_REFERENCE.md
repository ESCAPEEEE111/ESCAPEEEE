# API Reference — Nowhere Digital Backend

This document provides a summary of the main backend API endpoints.  
For interactive docs, run the backend and visit `/docs` or `/redoc`.

## Endpoints

### Contact Form

- **POST /api/contact/**
  - Submit a new contact form inquiry.
  - **Request JSON:**
    ```json
    {
      "name": "Your Name",
      "email": "your@email.com",
      "message": "Your inquiry here"
    }
    ```
  - **Response:**
    - `200 OK`, `{ "success": true, "message": "Contact form submitted." }`
    - Sends notification email (via SendGrid) and saves to MongoDB.

### Analytics

- **GET /api/analytics/summary**
  - Get today’s and total analytics (contacts, bookings, chat sessions, portfolio).
  - **Response:**
    ```json
    {
      "data": {
        "today": { ... },
        "total": { ... },
        "recent": { ... }
      }
    }
    ```

### AI Content

- **POST /api/ai/generate**
  - Generate content using OpenAI.
  - **Request JSON:**
    ```json
    {
      "prompt": "Write a marketing slogan for Nowhere Digital"
    }
    ```
  - **Response:** AI-generated result.

---

## Authentication

(Currently, public endpoints. Future versions will require authentication for admin, bookings, etc.)

## Error Handling

- Errors are returned as `{ "success": false, "message": "Error description" }`

## Contributing

For details on models, see backend code and `/docs` route in a running backend.

---