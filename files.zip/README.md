# Nowhere Digital — Digital Marketing Agency Platform

This repository contains the source code for Nowhere Digital, a Dubai-based digital marketing agency platform, featuring a Matrix-inspired frontend and a powerful FastAPI backend.

## Features

- Modern, animated React frontend (Matrix cyberpunk theme)
- FastAPI backend (Python) with MongoDB integration
- Digital marketing services showcase
- UAE market specialization
- Partner brand integrations
- Terminal-style UI
- Contact form (integrated with backend, MongoDB, and email notifications via SendGrid)
- Planned: Admin dashboard, AI-powered chatbot and content generation, portfolio/case studies, booking system, client portal

## Setup

### Backend

1. Install Python dependencies:
   ```bash
   pip install -r backend/requirements.txt
   ```
2. Copy `.env.example` to `.env` in the backend directory and fill in MongoDB, SendGrid, and OpenAI keys.
3. Run the backend:
   ```bash
   uvicorn backend.server:app --reload
   ```

### Frontend

1. Install dependencies:
   ```bash
   cd frontend
   npm install
   ```
2. Start the development server:
   ```bash
   npm start
   ```

## Testing

- The repository includes `test_result.md` and a structured testing protocol.
- Please refer to the `test_result.md` for test plans, tasks, and results.
- Run `npm test` in the frontend for UI tests.
- Backend API endpoints should be tested using tools like Postman or automated test suites.

## Contributing

- Please open issues or pull requests for bugs, new features, or enhancements.
- See `.emergent/summary.txt` for ongoing/planned development phases.

## Roadmap

- [ ] Test and validate contact form integration (DB save & email)
- [ ] Build admin dashboard for submissions, analytics, and content management
- [ ] Implement AI-powered chatbot and content generation
- [ ] Add portfolio/case studies section
- [ ] Integrate appointment booking system
- [ ] Launch client portal with authentication

---

For more information, see the frontend and backend README files.